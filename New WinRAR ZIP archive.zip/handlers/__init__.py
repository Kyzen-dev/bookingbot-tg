# from . import start, booking, admin
#
# def register_handlers(bot):
#     start.register_handlers(bot)
#     booking.register_handlers(bot)
    # admin.register_handlers(bot)